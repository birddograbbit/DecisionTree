#!/usr/bin/env python
"""
Test script for focal loss implementation in XGBoost.
"""

import pandas as pd
import numpy as np
from src.models.model_factory import ModelFactory
from src.data.preprocessing import preprocess_data
from src.features.feature_engineering import prepare_train_test_data

# Load data
data_path = 'data/raw'
symbol = 'SPY'

# Load data from raw directory
import os
csv_files = [f for f in os.listdir(data_path) if f.endswith('.csv') and 'SPY' in f]
dfs = []
for file in csv_files:
    file_path = os.path.join(data_path, file)
    dfs.append(pd.read_csv(file_path, index_col=0, parse_dates=True))
df = pd.concat(dfs).sort_index()
df = preprocess_data(df)

print(f"Data loaded. Shape: {df.shape}")
print(f"Date range: {df.index[0]} to {df.index[-1]}")

# Split data
train_size = 0.7
split_idx = int(len(df) * train_size)
train_data = df.iloc[:split_idx]
test_data = df.iloc[split_idx:]

# Prepare features
X_train, X_test, y_train, y_test, dates_train, dates_test, scaler = prepare_train_test_data(train_data)

print(f"\nTrain data: {X_train.shape}, {y_train.shape}")
print(f"Test data: {X_test.shape}, {y_test.shape}")

# Calculate class distribution
train_class_counts = np.bincount(y_train)
print(f"\nTraining class distribution:")
print(f"Down days (0): {train_class_counts[0]} ({train_class_counts[0]/len(y_train)*100:.1f}%)")
print(f"Up days (1): {train_class_counts[1]} ({train_class_counts[1]/len(y_train)*100:.1f}%)")

# Test 1: Standard XGBoost (no focal loss)
print("\n=== Test 1: Standard XGBoost ===")
model_standard = ModelFactory.create_model(
    'xgboost',
    n_estimators=100,
    max_depth=5,
    learning_rate=0.1,
    use_focal_loss=False
)

model_standard.train(X_train, y_train)
probs_standard = model_standard.predict(X_test)

# Get predictions for high confidence samples
high_conf_buy = np.sum(probs_standard > 0.65)
high_conf_sell = np.sum(probs_standard < 0.35)
print(f"High confidence predictions: Buy={high_conf_buy}, Sell={high_conf_sell}")

# Test 2: XGBoost with focal loss
print("\n=== Test 2: XGBoost with Focal Loss ===")
model_focal = ModelFactory.create_model(
    'xgboost',
    n_estimators=100,
    max_depth=5,
    learning_rate=0.1,
    use_focal_loss=True,
    focal_gamma=2.0,
    focal_alpha='auto'  # Automatically calculate from class distribution
)

model_focal.train(X_train, y_train)
probs_focal = model_focal.predict(X_test)

# Get predictions for high confidence samples
high_conf_buy_focal = np.sum(probs_focal > 0.65)
high_conf_sell_focal = np.sum(probs_focal < 0.35)
print(f"High confidence predictions: Buy={high_conf_buy_focal}, Sell={high_conf_sell_focal}")

# Compare distributions
print("\n=== Probability Distribution Comparison ===")
print(f"Standard XGBoost - Mean: {probs_standard.mean():.3f}, Std: {probs_standard.std():.3f}")
print(f"Focal Loss XGBoost - Mean: {probs_focal.mean():.3f}, Std: {probs_focal.std():.3f}")

# Test prediction accuracy on minority class (down days)
down_indices = y_test == 0
if np.any(down_indices):
    standard_down_acc = np.mean(probs_standard[down_indices] < 0.5)
    focal_down_acc = np.mean(probs_focal[down_indices] < 0.5)
    print(f"\nDown day prediction accuracy:")
    print(f"Standard: {standard_down_acc:.3f}")
    print(f"Focal Loss: {focal_down_acc:.3f}")

# Test 3: Custom focal parameters
print("\n=== Test 3: Custom Focal Parameters ===")
model_custom = ModelFactory.create_model(
    'xgboost',
    n_estimators=100,
    max_depth=5,
    learning_rate=0.1,
    use_focal_loss=True,
    focal_gamma=3.0,  # Higher focus on hard examples
    focal_alpha=0.43  # Based on 43% down days
)

model_custom.train(X_train, y_train)
probs_custom = model_custom.predict(X_test)

high_conf_buy_custom = np.sum(probs_custom > 0.65)
high_conf_sell_custom = np.sum(probs_custom < 0.35)
print(f"High confidence predictions: Buy={high_conf_buy_custom}, Sell={high_conf_sell_custom}")

print("\nFocal loss test complete.")